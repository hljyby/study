# self-vue
- vue数据双向绑定原理分析和简单实现
- 代码总共分为三个版本，v3为最终版本

## 效果图
![Mou icon](./selfvue.gif)
## 博客地址
[http://www.cnblogs.com/canfoo/p/6891868.html](http://www.cnblogs.com/canfoo/p/6891868.html)


