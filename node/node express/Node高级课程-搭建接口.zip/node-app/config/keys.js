module.exports = {
  mongoURI:"mongodb://test:123456@ds121960.mlab.com:21960/restful-api-prod",
  secretOrKey:"secret"
}